// src/lib/db.ts
import Database from 'better-sqlite3';
import path from 'path';

// Nama file database nanti akan muncul otomatis di folder project
const dbPath = path.join(process.cwd(), 'mountain-app.db');
const db = new Database(dbPath);

// Fungsi untuk membuat tabel otomatis jika belum ada
const initDb = () => {
  const sql = `
    CREATE TABLE IF NOT EXISTS mountains (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      location TEXT NOT NULL,
      height TEXT NOT NULL,
      description TEXT NOT NULL,
      imageUrl TEXT,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `;
  db.exec(sql);
};

// Jalankan inisialisasi tabel
initDb();

export default db;