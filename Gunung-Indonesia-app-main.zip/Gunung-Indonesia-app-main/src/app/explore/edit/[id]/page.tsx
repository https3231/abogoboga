// src/app/explore/edit/[id]/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation'; // Hooks untuk routing
import Link from 'next/link';

export default function EditPage() {
  const router = useRouter();
  const params = useParams(); // Mengambil id dari URL
  const id = params.id;

  const [formData, setFormData] = useState({
    name: '',
    location: '',
    height: '',
    description: '',
    imageUrl: ''
  });

  // Ambil data lama berdasarkan ID saat halaman dibuka
  useEffect(() => {
    fetchMountainDetail();
  }, []);

  const fetchMountainDetail = async () => {
    // Kita "curang" sedikit: ambil semua data lalu cari yang ID-nya cocok
    // (Idealnya buat API khusus GET by ID, tapi ini cukup untuk tugas mini)
    const res = await fetch('/api/mountains');
    const data = await res.json();
    const found = data.find((m: any) => m.id == id);
    
    if (found) {
      setFormData(found);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const res = await fetch('/api/mountains', {
      method: 'PUT', // Pakai PUT untuk update
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...formData, id }), // Kirim data beserta ID-nya
    });

    if (res.ok) {
      alert("Data berhasil diupdate!");
      router.push('/explore'); // Kembali ke halaman list
    } else {
      alert("Gagal update.");
    }
  };

  return (
    <div className="container py-5">
      <div className="card shadow border-0" style={{ maxWidth: '600px', margin: '0 auto' }}>
        <div className="card-header bg-warning text-dark fw-bold">
          Edit Data Gunung
        </div>
        <div className="card-body">
          <form onSubmit={handleUpdate}>
            {/* Form Input sama persis seperti di explore */}
            <div className="mb-3">
              <label className="form-label">Nama Gunung</label>
              <input type="text" className="form-control" value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})} />
            </div>
            
            <div className="mb-3">
              <label className="form-label">Lokasi</label>
              <input type="text" className="form-control" value={formData.location}
                onChange={(e) => setFormData({...formData, location: e.target.value})} />
            </div>

            <div className="mb-3">
              <label className="form-label">Ketinggian</label>
              <input type="text" className="form-control" value={formData.height}
                onChange={(e) => setFormData({...formData, height: e.target.value})} />
            </div>

            <div className="mb-3">
              <label className="form-label">URL Gambar</label>
              <input type="text" className="form-control" value={formData.imageUrl}
                onChange={(e) => setFormData({...formData, imageUrl: e.target.value})} />
            </div>

            <div className="mb-3">
              <label className="form-label">Deskripsi</label>
              <textarea className="form-control" rows={4} value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}></textarea>
            </div>

            <div className="d-flex gap-2">
              <button type="submit" className="btn btn-warning flex-grow-1">Simpan Perubahan</button>
              <Link href="/explore" className="btn btn-secondary">Batal</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}