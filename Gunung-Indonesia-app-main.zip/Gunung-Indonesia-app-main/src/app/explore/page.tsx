// src/app/explore/page.tsx
'use client'; 

import { useState, useEffect } from 'react';
import Link from 'next/link'; // <--- Penting: Import Link untuk tombol Edit

type Mountain = {
  id: number;
  name: string;
  location: string;
  height: string;
  description: string;
  imageUrl: string;
};

export default function ExplorePage() {
  const [mountains, setMountains] = useState<Mountain[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // State Form
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    height: '',
    description: '',
    imageUrl: ''
  });

  // Ambil data saat halaman dibuka
  useEffect(() => {
    fetchMountains();
  }, []);

  const fetchMountains = async () => {
    try {
      const res = await fetch('/api/mountains');
      const data = await res.json();
      setMountains(data);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setIsLoading(false);
    }
  };

  // Fungsi Tambah Data (Create)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if(!formData.name || !formData.location) return alert("Nama & Lokasi wajib diisi");

    const res = await fetch('/api/mountains', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    if (res.ok) {
      alert('Data berhasil disimpan!');
      setFormData({ name: '', location: '', height: '', description: '', imageUrl: '' });
      fetchMountains(); 
    }
  };

  // Fungsi Hapus Data (Delete) - INI YANG BARU
  const handleDelete = async (id: number) => {
    if (!confirm("Yakin ingin menghapus data ini?")) return;

    const res = await fetch(`/api/mountains?id=${id}`, {
      method: 'DELETE',
    });

    if (res.ok) {
      alert("Data berhasil dihapus!");
      fetchMountains(); // Refresh list agar data hilang dari layar
    } else {
      alert("Gagal menghapus.");
    }
  };

  return (
    <div className="min-vh-100 bg-light py-5">
      <div className="container">
        
        {/* Header */}
        <div className="d-flex justify-content-between align-items-center mb-5">
          <h1 className="fw-bold text-dark">Jelajah Gunung</h1>
          <Link href="/" className="btn btn-outline-secondary">
            &larr; Kembali ke Home
          </Link>
        </div>

        <div className="row g-4">
          
          {/* Form Input */}
          <div className="col-md-4">
            <div className="card shadow-sm border-0 sticky-top" style={{ top: '20px' }}>
              <div className="card-header bg-primary text-white">
                <h5 className="mb-0">Tambah Data Baru</h5>
              </div>
              <div className="card-body">
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label className="form-label">Nama Gunung</label>
                    <input type="text" className="form-control" value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})} />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Lokasi</label>
                    <input type="text" className="form-control" value={formData.location}
                      onChange={(e) => setFormData({...formData, location: e.target.value})} />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Ketinggian</label>
                    <input type="text" className="form-control" value={formData.height}
                      onChange={(e) => setFormData({...formData, height: e.target.value})} />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">URL Gambar</label>
                    <input type="text" className="form-control" value={formData.imageUrl}
                      onChange={(e) => setFormData({...formData, imageUrl: e.target.value})} />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Deskripsi</label>
                    <textarea className="form-control" rows={3} value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}></textarea>
                  </div>
                  <button type="submit" className="btn btn-primary w-100">+ Simpan Data</button>
                </form>
              </div>
            </div>
          </div>

          {/* List Data */}
          <div className="col-md-8">
            <h4 className="mb-3 text-secondary">Koleksi Gunung ({mountains.length})</h4>
            
            {isLoading ? <p>Loading...</p> : (
              <div className="row g-3">
                {mountains.map((item) => (
                  <div key={item.id} className="col-12">
                    <div className="card border-0 shadow-sm overflow-hidden">
                      <div className="row g-0">
                        <div className="col-md-4">
                          <img 
                            src={item.imageUrl || "https://placehold.co/600x400?text=No+Image"} 
                            className="img-fluid h-100 object-fit-cover" 
                            alt={item.name}
                            style={{ minHeight: '200px', width: '100%' }}
                          />
                        </div>
                        <div className="col-md-8">
                          <div className="card-body h-100 d-flex flex-column">
                            <div className="mb-auto">
                              <h3 className="card-title fw-bold">{item.name}</h3>
                              <p className="text-muted mb-2">📍 {item.location} • ⛰️ {item.height}</p>
                              <p className="card-text text-truncate">{item.description}</p>
                            </div>
                            
                            {/* TOMBOL EDIT & DELETE */}
                            <div className="mt-3">
                              {/* Tombol Edit mengarah ke halaman edit/[id] */}
                              <Link href={`/explore/edit/${item.id}`} className="btn btn-sm btn-outline-warning me-2">
                                Edit
                              </Link>
                              
                              {/* Tombol Delete memanggil fungsi handleDelete */}
                              <button 
                                onClick={() => handleDelete(item.id)} 
                                className="btn btn-sm btn-outline-danger"
                              >
                                Delete
                              </button>
                            </div>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}