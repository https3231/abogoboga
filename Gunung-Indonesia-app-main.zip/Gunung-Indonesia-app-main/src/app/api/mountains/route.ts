// src/app/api/mountains/route.ts
import { NextResponse } from "next/server";
import db from "@/lib/db";

// Interface untuk data Gunung (agar TypeScript senang)
type Mountain = {
  id: number;
  name: string;
  location: string;
  height: string;
  description: string;
  imageUrl: string | null;
  createdAt: string;
};

// 1. GET: Untuk mengambil semua data gunung
export async function GET() {
  try {
    const stmt = db.prepare('SELECT * FROM mountains ORDER BY createdAt DESC');
    const data = stmt.all() as Mountain[];
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: "Gagal mengambil data" }, { status: 500 });
  }
}

// 2. POST: Untuk menambah data gunung baru
export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // Validasi sederhana
    if (!body.name || !body.location) {
      return NextResponse.json({ error: "Nama dan Lokasi wajib diisi" }, { status: 400 });
    }

    const stmt = db.prepare(`
      INSERT INTO mountains (name, location, height, description, imageUrl)
      VALUES (?, ?, ?, ?, ?)
    `);

    const info = stmt.run(
      body.name,
      body.location,
      body.height,
      body.description,
      body.imageUrl || "" // Jika tidak ada gambar, simpan string kosong
    );

    return NextResponse.json({ 
      message: "Berhasil disimpan",
      id: info.lastInsertRowid 
    }, { status: 201 });

  } catch (error) {
    console.error("Database Error:", error);
    return NextResponse.json({ error: "Gagal menyimpan data" }, { status: 500 });
  }
}
// src/app/api/mountains/route.ts

// ... (Kode GET dan POST sebelumnya biarkan saja, JANGAN DIHAPUS) ...

// 3. DELETE: Untuk menghapus data berdasarkan ID
export async function DELETE(request: Request) {
    try {
      // Ambil ID dari URL (contoh: /api/mountains?id=1)
      const { searchParams } = new URL(request.url);
      const id = searchParams.get('id');
  
      if (!id) {
        return NextResponse.json({ error: "ID diperlukan" }, { status: 400 });
      }
  
      const stmt = db.prepare('DELETE FROM mountains WHERE id = ?');
      stmt.run(id);
  
      return NextResponse.json({ message: "Berhasil dihapus" });
    } catch (error) {
      return NextResponse.json({ error: "Gagal menghapus data" }, { status: 500 });
    }
  }
  
  // 4. PUT: Untuk mengupdate data (Edit)
  export async function PUT(request: Request) {
    try {
      const body = await request.json();
      
      const stmt = db.prepare(`
        UPDATE mountains 
        SET name = ?, location = ?, height = ?, description = ?, imageUrl = ?
        WHERE id = ?
      `);
  
      stmt.run(
        body.name, 
        body.location, 
        body.height, 
        body.description, 
        body.imageUrl, 
        body.id
      );
  
      return NextResponse.json({ message: "Berhasil diupdate" });
    } catch (error) {
      return NextResponse.json({ error: "Gagal update data" }, { status: 500 });
    }
  }