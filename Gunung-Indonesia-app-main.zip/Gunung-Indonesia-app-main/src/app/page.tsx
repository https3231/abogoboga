// src/app/page.tsx
import Link from "next/link";
import Image from "next/image";

export default function Home() {
  return (
    <main className="d-flex min-vh-100 flex-column bg-light">
      
      {/* Navbar Sederhana */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div className="container">
          <span className="navbar-brand fw-bold">IndoMountain</span>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="container my-auto">
        <div className="row justify-content-center">
          <div className="col-md-8">
            <div className="card shadow-lg border-0 rounded-4 overflow-hidden">
              
              {/* Gambar Header */}
              <div className="position-relative" style={{ height: '350px' }}>
                {/* Ganti URL gambar jika ingin gambar gunung lain */}
                <img 
                  src="https://images.unsplash.com/photo-1589308078059-be1415eab4c3?q=80&w=1000&auto=format&fit=crop" 
                  alt="Gunung Bromo" 
                  className="w-100 h-100 object-fit-cover"
                />
                <div className="position-absolute top-0 start-0 w-100 h-100 d-flex flex-column justify-content-center align-items-center text-center p-3" style={{ background: 'rgba(0,0,0,0.5)' }}>
                  <h1 className="text-white display-4 fw-bold">INDONESIA WONDERFUL</h1>
                  <p className="text-white-50 lead">Keindahan Puncak Nusantara</p>
                  <p className="text-white-50 lead">Untuk Kita Yang Berdiri Sama Rata</p>
                </div>
              </div>

              {/* Identitas Mahasiswa & Tombol Mulai */}
              <div className="card-body p-5 text-center">
                <h6 className="text-uppercase text-primary fw-bold letter-spacing-2 mb-3">
                  
                </h6>
                
                {/* Ganti dengan Nama & NIM Kamu */}
                <h2 className="fw-bold text-dark">ARIA SANTOSA GUNAWAN</h2>
                <h4 className="text-secondary mb-4">NIM:535240047</h4>
                
                <hr className="w-50 mx-auto my-4" />

                <p className="card-text text-muted mb-4">
                  Aplikasi ini saya buat untuk mendata dan menampilkan informasi mengenai 
                  gunung-gunung indah yang tersebar di seluruh penjuru Indonesia.
                </p>

                {/* Tombol ini mengarah ke folder /explore tempat fitur CRUD berada */}
                <Link href="/explore" className="btn btn-dark btn-lg rounded-pill px-5">
                  Mulai Jelajahi
                </Link>
              </div>

            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-3 text-center text-muted small">
        &copy; 2025 Mountain App Project
      </footer>

    </main>
  );
}